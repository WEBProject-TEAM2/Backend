package org.team2project.camealone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CameAloneApplication {

    public static void main(String[] args) {
        SpringApplication.run(CameAloneApplication.class, args);
    }

}
