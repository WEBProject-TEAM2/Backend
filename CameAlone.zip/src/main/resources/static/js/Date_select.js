
function keep_complete(){ // 담기 버튼을 눌렀을 시 동작 될 코드
    alert("리스트에 담겼습니다")
}
