package org.team2project.camealone.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "LikeList") // 찜목록 테이블
public class LikeList {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "number")
    private Long number;

    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "rating", nullable = false)
    private Double rating;

    @Column(name = "contact", nullable = false, length = 255)
    private String contact;

    // 기본 생성자
    public LikeList() {
    }

    // 생성자
    public LikeList(String name, Double rating, String contact) {
        this.name = name;
        this.rating = rating;
        this.contact = contact;
    }

    // Getter 및 Setter 메서드
    public Long getNumber() {
        return number;
    }

    public void setNumber(Long number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getRating() {return rating;}

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
}
