package com.example.honjawatni;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpSession;
import java.util.HashMap;

@RestController
public class HomeController {

    private final KakaoLoginService kakaoApi;

    @Autowired
    public HomeController(KakaoLoginService kakaoApi) {
        this.kakaoApi = kakaoApi;
    }

    @RequestMapping(value="/login")
    public ModelAndView login(@RequestParam("code") String code, HttpSession session) {
        ModelAndView mav = new ModelAndView();
        // 1번 인증코드 요청 전달
        String accessToken = kakaoApi.getAccessToken(code);
        // 2번 인증코드로 토큰 전달
        HashMap<String, Object> userInfo = kakaoApi.getUserInfo(accessToken);

        System.out.println("login info : " + userInfo.toString());

        if (accessToken != null && !accessToken.isEmpty()) {
            session.setAttribute("accessToken", accessToken);
            mav.addObject("userInfo", userInfo);  // 필요 시 사용자 정보를 추가
        }
        mav.setViewName("index");
        return mav;
    }

    @PostMapping(value="/logout")
    public ModelAndView logout(HttpSession session) {
        ModelAndView mav = new ModelAndView();

        String accessToken = (String) session.getAttribute("accessToken");
        if (accessToken != null) {
            kakaoApi.kakaoLogout(accessToken);
            session.removeAttribute("accessToken");
        }
        mav.setViewName("index");
        return mav;
    }
}
